import React from 'react';

const styles = {
  bar: {
    background: '#a8f0d8',
    textAlign: 'center',
    padding: '10px 20px',
    fontSize: '13px',
    fontWeight: '600',
    letterSpacing: '0.01em',
    cursor: 'pointer',
    userSelect: 'none',
  },
};

export default function AnnouncementBar() {
  return (
    <div style={styles.bar}>
      <span style={{ marginRight: '6px' }}>🔴</span>
      Where are your customers actually searching? Download the report ↗
    </div>
  );
}
