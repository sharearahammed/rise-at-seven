import React, { useEffect, useRef } from 'react';

const PLATFORMS = [
  { icon: 'G', label: 'Google' },
  { icon: '✦', label: 'ChatGPT' },
  { icon: '◈', label: 'Gemini' },
  { icon: '♪', label: 'TikTok' },
  { icon: '▶', label: 'YouTube' },
  { icon: '📌', label: 'Pinterest' },
  { icon: '⊕', label: 'GIPHY' },
  { icon: '◉', label: 'reddit' },
  { icon: 'a', label: 'amazon' },
];

const AWARDS = [
  'GLOBAL SEARCH AWARDS',
  'THE DRUM',
  'UK SOCIAL MEDIA AWARDS',
  'CONTENT AWARDS',
];

export default function Hero() {
  return (
    <section style={{
      position: 'relative',
      minHeight: 'calc(100vh - 90px)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      overflow: 'hidden',
      background: 'linear-gradient(135deg, #d4c49e 0%, #b8a070 40%, #c8a060 70%, #d4b878 100%)',
    }}>
      {/* Airplane SVG background */}
      <svg
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          opacity: 0.18,
          pointerEvents: 'none',
        }}
        viewBox="0 0 1440 800"
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="xMidYMid slice"
      >
        {/* Airplane body */}
        <ellipse cx="720" cy="520" rx="680" ry="110" fill="#5a3a00" />
        {/* Fuselage */}
        <rect x="100" y="460" width="1240" height="80" rx="40" fill="#3a2800" />
        {/* Nose */}
        <ellipse cx="1300" cy="500" rx="140" ry="40" fill="#2a1800" />
        {/* Wings */}
        <polygon points="580,500 780,350 900,500" fill="#2a1800" opacity="0.8" />
        <polygon points="860,500 760,640 640,500" fill="#3a2800" opacity="0.6" />
        {/* Tail */}
        <polygon points="120,480 250,360 280,480" fill="#2a1800" opacity="0.7" />
        {/* Windows row */}
        {[400, 470, 540, 610, 680, 750, 820, 890, 960, 1030, 1100, 1170].map((x, i) => (
          <ellipse key={i} cx={x} cy="490" rx="16" ry="14" fill="rgba(255,255,150,0.15)" />
        ))}
      </svg>

      {/* Gradient overlay */}
      <div style={{
        position: 'absolute',
        inset: 0,
        background: 'linear-gradient(to bottom, rgba(180,130,60,0.3) 0%, rgba(120,80,20,0.15) 100%)',
        pointerEvents: 'none',
      }} />

      {/* Content */}
      <div style={{
        position: 'relative',
        zIndex: 2,
        padding: '40px 24px 80px',
        maxWidth: '1200px',
        width: '100%',
        margin: '0 auto',
      }}>
        {/* Award text */}
        <p style={{
          fontSize: '11px',
          fontWeight: 700,
          letterSpacing: '0.12em',
          textTransform: 'uppercase',
          color: 'rgba(255,255,255,0.9)',
          marginBottom: '10px',
        }}>
          #1 MOST RECOMMENDED<br />CONTENT MARKETING AGENCY
        </p>

        {/* Award badges */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexWrap: 'wrap',
          gap: '10px',
          marginBottom: '28px',
        }}>
          {AWARDS.map((award) => (
            <span key={award} style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '5px',
              color: 'rgba(255,255,255,0.85)',
              fontSize: '10px',
              fontWeight: 700,
              border: '1.5px solid rgba(255,255,255,0.4)',
              borderRadius: '6px',
              padding: '4px 10px',
              letterSpacing: '0.06em',
            }}>
              ⚡ {award}
            </span>
          ))}
        </div>

        {/* Main headline */}
        <h1 style={{
          fontSize: 'clamp(52px, 9vw, 140px)',
          fontWeight: 900,
          letterSpacing: '-0.04em',
          lineHeight: 0.95,
          color: '#ffffff',
          marginBottom: '20px',
          fontFamily: 'Plus Jakarta Sans, sans-serif',
        }}>
          We Create<br />
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.1em', flexWrap: 'wrap', justifyContent: 'center' }}>
            Category
            {/* Inline image - Emirates */}
            <span style={{
              display: 'inline-block',
              width: 'clamp(58px, 8vw, 108px)',
              height: 'clamp(58px, 8vw, 108px)',
              borderRadius: '16px',
              overflow: 'hidden',
              verticalAlign: 'middle',
              margin: '0 8px',
              boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
              background: 'linear-gradient(135deg, #e8c870, #c47830)',
              flexShrink: 0,
            }}>
              <svg viewBox="0 0 108 108" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                <rect width="108" height="108" fill="#c47830" />
                <rect x="0" y="55" width="108" height="53" fill="#a05c20" />
                <text x="54" y="46" fontSize="13" fontWeight="900" fill="white" textAnchor="middle" fontFamily="sans-serif">Emirates</text>
                <rect x="10" y="58" width="88" height="3" fill="rgba(255,255,255,0.5)" rx="2" />
                <text x="54" y="80" fontSize="10" fontWeight="600" fill="rgba(255,255,255,0.7)" textAnchor="middle" fontFamily="sans-serif">✈ Airline</text>
              </svg>
            </span>
            Leaders
          </span>
        </h1>

        {/* Subtitle */}
        <p style={{
          fontSize: 'clamp(15px, 2.5vw, 24px)',
          fontWeight: 400,
          color: 'rgba(255,255,255,0.9)',
          fontStyle: 'italic',
          marginBottom: '40px',
          letterSpacing: '0.01em',
        }}>
          on every searchable platform
        </p>

        {/* Platform logos */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexWrap: 'wrap',
          gap: '24px',
        }}>
          {PLATFORMS.map((p) => (
            <span key={p.label} style={{
              color: 'rgba(255,255,255,0.88)',
              fontSize: '14px',
              fontWeight: 700,
              display: 'flex',
              alignItems: 'center',
              gap: '5px',
            }}>
              <span style={{ opacity: 0.7 }}>{p.icon}</span>
              {p.label}
            </span>
          ))}
        </div>
      </div>

      {/* Bottom row */}
      <div style={{
        position: 'absolute',
        bottom: '20px',
        left: '24px',
        right: '24px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-end',
        color: 'rgba(255,255,255,0.75)',
        fontSize: '12px',
        fontWeight: 500,
        zIndex: 2,
        flexWrap: 'wrap',
        gap: '8px',
      }}>
        <span>Organic media planners creating, distributing &amp; optimising<br />search-first content for SEO, Social, PR, AI and LLM search</span>
        <span style={{ textAlign: 'right' }}>4 Global Offices serving<br />UK, US, Australia &amp; beyond</span>
      </div>

      <style>{`
        @media (max-width: 600px) {
          section > div:last-child { display: none; }
        }
      `}</style>
    </section>
  );
}
