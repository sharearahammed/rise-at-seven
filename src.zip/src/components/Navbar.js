import React, { useState, useEffect } from 'react';

const NAV_LINKS = [
  { label: 'Services', suffix: ' +' },
  { label: 'International', suffix: ' +' },
  { label: 'About', suffix: ' +' },
  { label: 'Work', badge: '25' },
  { label: 'Careers' },
  { label: 'Blog' },
  { label: 'Webinar' },
];

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [menuOpen]);

  return (
    <>
      <nav style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        background: 'rgba(255,255,255,0.92)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        borderBottom: '1px solid rgba(0,0,0,0.06)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 32px',
        height: '64px',
        boxShadow: scrolled ? '0 2px 20px rgba(0,0,0,0.08)' : 'none',
        transition: 'box-shadow 0.3s ease',
      }}>
        {/* Logo */}
        <a href="#" style={{
          fontSize: '20px',
          fontWeight: 800,
          letterSpacing: '-0.03em',
          textDecoration: 'none',
          color: '#0a0a0a',
          fontFamily: 'Plus Jakarta Sans, sans-serif',
        }}>
          Rise at Seven↗
        </a>

        {/* Desktop Links */}
        <ul style={{
          display: 'flex',
          alignItems: 'center',
          gap: '28px',
          listStyle: 'none',
        }} className="desktop-nav">
          {NAV_LINKS.map((link) => (
            <li key={link.label}>
              <a
                href="#"
                style={{
                  fontSize: '14px',
                  fontWeight: 500,
                  textDecoration: 'none',
                  color: '#0a0a0a',
                  opacity: 0.85,
                  transition: 'opacity 0.2s',
                  fontFamily: 'Plus Jakarta Sans, sans-serif',
                }}
                onMouseEnter={e => e.target.style.opacity = '1'}
                onMouseLeave={e => e.target.style.opacity = '0.85'}
              >
                {link.label}{link.suffix || ''}
                {link.badge && (
                  <span style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '20px',
                    height: '20px',
                    background: '#a8f0d8',
                    borderRadius: '50%',
                    fontSize: '10px',
                    fontWeight: 700,
                    marginLeft: '4px',
                    verticalAlign: 'middle',
                  }}>{link.badge}</span>
                )}
              </a>
            </li>
          ))}
        </ul>

        {/* Desktop CTA */}
        <a
          href="#"
          className="desktop-cta"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            padding: '10px 20px',
            border: '1.5px solid #0a0a0a',
            borderRadius: '100px',
            fontSize: '13px',
            fontWeight: 600,
            textDecoration: 'none',
            color: '#0a0a0a',
            background: 'transparent',
            transition: 'background 0.2s, color 0.2s',
            fontFamily: 'Plus Jakarta Sans, sans-serif',
          }}
          onMouseEnter={e => { e.currentTarget.style.background = '#0a0a0a'; e.currentTarget.style.color = '#fff'; }}
          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#0a0a0a'; }}
        >
          Get In Touch ↗
        </a>

        {/* Hamburger */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="hamburger-btn"
          aria-label="Toggle menu"
          style={{
            display: 'none',
            flexDirection: 'column',
            gap: '5px',
            cursor: 'pointer',
            background: 'none',
            border: 'none',
            padding: '4px',
          }}
        >
          <span style={{
            display: 'block', width: '24px', height: '2px',
            background: '#0a0a0a', borderRadius: '2px',
            transition: 'transform 0.3s, opacity 0.3s',
            transform: menuOpen ? 'translateY(7px) rotate(45deg)' : 'none',
          }} />
          <span style={{
            display: 'block', width: '24px', height: '2px',
            background: '#0a0a0a', borderRadius: '2px',
            transition: 'opacity 0.3s',
            opacity: menuOpen ? 0 : 1,
          }} />
          <span style={{
            display: 'block', width: '24px', height: '2px',
            background: '#0a0a0a', borderRadius: '2px',
            transition: 'transform 0.3s, opacity 0.3s',
            transform: menuOpen ? 'translateY(-7px) rotate(-45deg)' : 'none',
          }} />
        </button>
      </nav>

      {/* Mobile Menu */}
      <div style={{
        position: 'fixed',
        inset: 0,
        top: '64px',
        background: '#ffffff',
        zIndex: 99,
        display: 'flex',
        flexDirection: 'column',
        padding: '32px 24px',
        overflowY: 'auto',
        transform: menuOpen ? 'translateX(0)' : 'translateX(100%)',
        transition: 'transform 0.35s cubic-bezier(0.4,0,0.2,1)',
      }} className="mobile-menu">
        {NAV_LINKS.map((link) => (
          <a
            key={link.label}
            href="#"
            onClick={() => setMenuOpen(false)}
            style={{
              display: 'block',
              fontSize: '28px',
              fontWeight: 700,
              letterSpacing: '-0.02em',
              color: '#0a0a0a',
              textDecoration: 'none',
              padding: '18px 0',
              borderBottom: '1px solid rgba(0,0,0,0.08)',
              fontFamily: 'Plus Jakarta Sans, sans-serif',
            }}
          >
            {link.label}
          </a>
        ))}
        <a
          href="#"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            padding: '14px 28px',
            border: '1.5px solid #0a0a0a',
            borderRadius: '100px',
            fontSize: '15px',
            fontWeight: 600,
            textDecoration: 'none',
            color: '#0a0a0a',
            marginTop: '28px',
            width: 'fit-content',
            fontFamily: 'Plus Jakarta Sans, sans-serif',
          }}
        >
          Get In Touch ↗
        </a>
      </div>

      {/* Responsive CSS */}
      <style>{`
        @media (max-width: 900px) {
          .desktop-nav { display: none !important; }
          .desktop-cta { display: none !important; }
          .hamburger-btn { display: flex !important; }
        }
      `}</style>
    </>
  );
}
