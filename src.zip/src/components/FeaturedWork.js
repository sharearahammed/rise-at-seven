"use client";

import { useEffect, useRef, useState } from "react";
import SixtImage from "../assets/image/SIXT.jpg";
import DojoImage from "../assets/image/Dojo-B2B.jpg";
import MagnetImage from "../assets/image/Magnet.png";
import ESimImage from "../assets/image/Learning E Sim.jpg";
import JDSportsImage from "../assets/image/JD Sports.jpg";
import ParkdeanImage from "../assets/image/Parkdean Resorts.jpg";
import PookyImage from "../assets/image/Pooky.jpg";
import RevolutionBeautyImage from "../assets/image/Revolution Beauty.png";
import LloydsImage from "../assets/image/Lloyds Pharmacy.png";
import PLTImage from "../assets/image/PrettyLittleTing.png";

const WORKS = [
  { name: "SIXT", years: "[2023-2025]" },
  { name: "Dojo – B2B", years: "[2021-2025]" },
  { name: "Magnet Trade – B2B", years: "[2023-2024]" },
  { name: "Leading E Sim", years: "[2023-2025]" },
  { name: "JD Sports", years: "[2025]" },
  { name: "Parkdean Resorts", years: "[2019-2025]" },
  { name: "Pooky", years: "[2025]" },
  { name: "Revolution Beauty", years: "[2022-2025]" },
  { name: "Lloyds Pharmacy", years: "[2022-2023]" },
  { name: "PrettyLittleThing", years: "[2021-2023]" },
];

const CHIPS = [
  { label: "🔍 Car rental 📈", bg: "rgba(255,255,255,0.92)", color: "#0a0a0a" },
  { label: "💳 Payments B2B", bg: "rgba(255,255,255,0.92)", color: "#0a0a0a" },
  { label: "🛠 Trade tools ↗", bg: "rgba(0,200,100,0.15)", color: "#7ecb98" },
  { label: "🌐 Global eSIM", bg: "rgba(90,184,255,0.15)", color: "#5ab8ff" },
  { label: "👟 Sportswear 📈", bg: "rgba(255,255,255,0.92)", color: "#0a0a0a" },
  {
    label: "🏖 Resorts & Travel",
    bg: "rgba(255,255,255,0.92)",
    color: "#0a0a0a",
  },
  {
    label: "💡 Lighting Design",
    bg: "rgba(255,200,50,0.15)",
    color: "#f0c040",
  },
  {
    label: "💄 Beauty & Skincare",
    bg: "rgba(255,100,180,0.15)",
    color: "#ff80c0",
  },
  { label: "💊 Pharmacy", bg: "rgba(100,200,255,0.15)", color: "#60c8ff" },
  { label: "👗 Fashion 📈", bg: "rgba(255,255,255,0.92)", color: "#0a0a0a" },
];

const IMAGES = [
  SixtImage,
  DojoImage,
  MagnetImage,
  ESimImage,
  JDSportsImage,
  ParkdeanImage,
  PookyImage,
  RevolutionBeautyImage,
  LloydsImage,
  PLTImage,
];

// ── Component ─────────────────────────────────────────────────────────────

export default function FeaturedWork() {
  const [activeIdx, setActiveIdx] = useState(0);
  const [hoverIdx, setHoverIdx] = useState(null);
  const rowRefs = useRef([]);

  useEffect(() => {
    const observers = [];

    rowRefs.current.forEach((el, i) => {
      if (!el) return;
      const obs = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) setActiveIdx(i);
        },
        { threshold: 0.5 },
      );
      obs.observe(el);
      observers.push(obs);
    });

    return () => observers.forEach((o) => o.disconnect());
  }, []);

  return (
    <>
      <section style={{ background: "#0a0a0a" }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            minHeight: "100vh",
          }}
          className="fw-grid"
        >
          {/* LEFT — sticky work list */}
          <div
            style={{
              position: "sticky",
              top: 0,
              height: "100vh",
              padding: "70px 50px",
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
            }}
            className="fw-left"
          >
            <p
              style={{
                fontSize: "11px",
                fontWeight: 700,
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                color: "rgba(255,255,255,0.35)",
                marginBottom: "44px",
              }}
            >
              Featured Work
            </p>

            {WORKS.map((work, i) => (
              <div
                key={work.name}
                style={{
                  padding: "14px 0",
                  borderBottom: "1px solid rgba(255,255,255,0.08)",
                  borderTop:
                    i === 0 ? "1px solid rgba(255,255,255,0.08)" : "none",
                }}
              >
                <p
                className="font"
                  style={{
                    fontSize: "clamp(16px, 2.6vw, 42px)",
                    fontWeight: 900,
                    letterSpacing: "-0.03em",
                    fontFamily: "Plus Jakarta Sans, sans-serif",
                    color:
                      activeIdx === i ? "#ffffff" : "rgba(255,255,255,0.2)",
                    transition: "color 0.3s ease",
                    display: "inline",
                  }}
                >
                  {work.name}
                </p>
                <span
                  style={{
                    fontSize: "11px",
                    fontWeight: 600,
                    color: "rgba(255,255,255,0.3)",
                    marginLeft: "10px",
                    verticalAlign: "middle",
                  }}
                >
                  {work.years}
                </span>
              </div>
            ))}
          </div>

          {/* RIGHT — stacked image rows, normal scroll */}
          <div>
            {WORKS.map((_, i) => {
              const imgSrc = IMAGES[i];
              const chip = CHIPS[i];

              const hoverData = [
                {
                  color: "#CB7B3A",
                  text: "An extra 3m clicks regionally through SEO",
                },
                {
                  color: "#FDD8C4",
                  text: "A B2B success story for Dojo card machines",
                },
                {
                  color: "#D8C4FD",
                  text: "A full service SEO success story 170%+ increase",
                },
                {
                  color: "#CB7B3A",
                  text: "Increasing brand and non brand visibility UK/ES",
                },
                {
                  color: "#3A8CCB",
                  text: "65% up YoY in clicks for JDSports FR, IT, ES",
                },
                { color: "#D2B59D", text: "Dominating Google and AI search" },
                {
                  color: "#39B0BD",
                  text: "Driving demand for Pooky Rechargeable Lights",
                },
                {
                  color: "#D29DD0",
                  text: "Social search and multi channel content to #1",
                },
                {
                  color: "#D29DD0",
                  text: "Building the UK's leading beauty dupe brand",
                },
                {
                  color: "#FECACC",
                  text: 'Driving discovery for everything "outfits" for PLT',
                },
              ][i];

              return (
                <div
                  key={i}
                  ref={(el) => (rowRefs.current[i] = el)}
                  onMouseEnter={() => setHoverIdx(i)}
                  onMouseLeave={() => setHoverIdx(null)}
                  style={{
                    position: "relative",
                    padding: "20px", // ✅ padding here
                    overflow: "hidden",
                    cursor: "pointer",
                  }}
                >
                  {/* IMAGE WRAPPER */}
                  <div
                    style={{
                      position: "relative",
                      borderRadius: "10px",
                      overflow: "hidden",
                    }}
                  >
                    <img
                      src={imgSrc}
                      alt={WORKS[i].name}
                      style={{
                        width: "100%",
                        height: "auto",
                        objectFit: "cover",
                        display: "block",
                      }}
                    />

                    {/* OVERLAY */}
                    <div
                      style={{
                        position: "absolute",
                        left: "50%",
                        bottom: "0%",
                        width: "250%",
                        height: "250%",
                        background: hoverData.color,
                        borderRadius: "50%",
                        transform:
                          hoverIdx === i
                            ? "translate(-50%, 50%) scale(1)"
                            : "translate(-50%, 50%) scale(0)",
                        transition:
                          "transform 0.45s cubic-bezier(0.4, 0, 0.2, 1)",
                        pointerEvents: "none",
                      }}
                    />

                    {/* TEXT */}
                    <div
                      style={{
                        position: "absolute",
                        inset: 0,
                        padding: "20px",
                        fontSize: "28px",
                        fontWeight: 800,
                        color: "#fff",
                        opacity: hoverIdx === i ? 1 : 0,
                        transition: "opacity 0.3s ease",
                        pointerEvents: "none",
                      }}
                    >
                      {hoverData.text}
                    </div>
                  </div>

                  {/* CHIP */}
                  <div
                    style={{
                      position: "absolute",
                      bottom: "14px",
                      right: "14px",
                      background: chip.bg,
                      backdropFilter: "blur(8px)",
                      borderRadius: "100px",
                      padding: "5px 12px",
                      fontSize: "11px",
                      fontWeight: 600,
                      color: chip.color,
                      display: "flex",
                      alignItems: "center",
                      gap: "5px",
                    }}
                  >
                    {chip.label}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <style>{`
        @media (max-width: 900px) {
          .fw-grid {
            grid-template-columns: 1fr !important;
          }
          .fw-left {
            position: relative !important;
            height: auto !important;
            padding: 40px 24px !important;
          }
        }
      `}</style>
    </>
  );
}
